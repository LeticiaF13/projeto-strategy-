package br.edu.umfg.estrategia;

public interface MeioPagamentoEstrategia {
    void pagar(Double valor);
}
